console.log("letmepdf is running on this page!");

(function () {
    "use strict";
    document.onload = () => {
        document.querySelectorAll(".activityname .aalink").forEach((elm) => {
            fetch(elm.href)
                .then((d) => d.text())
                .then((text) => {
                    const regex = /object id="resourceobject"\s+data="([^"]+)"/;
                    const match = text.match(regex);
                    const dataUrl = match ? match[1] : null;
                    if (dataUrl) {
                        elm.href = dataUrl;
                    }
                });
        });
    };
})();

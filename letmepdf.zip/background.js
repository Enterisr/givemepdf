chrome.runtime.onInstalled.addListener(() => {
  console.log("Moodle Course Extension installed.");
}); 